/* why js or jq ...!lets play with out it */
/* Make it simple */
/* Pure css */
/* check this out=> https://bootsnipp.com/Winson222  */

;
