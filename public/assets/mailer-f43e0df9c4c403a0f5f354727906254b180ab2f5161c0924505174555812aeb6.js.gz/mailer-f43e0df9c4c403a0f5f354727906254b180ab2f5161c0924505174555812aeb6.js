https://reallygoodemails.com/transactional/alert/reset-your-lingo-password/

You have got a new password.
The Password for username {} hasbeen successfully changed.

I didn't request! Help [button]
;
